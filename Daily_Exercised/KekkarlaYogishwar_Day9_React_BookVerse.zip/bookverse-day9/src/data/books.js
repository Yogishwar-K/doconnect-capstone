export const featuredBooks = [
  { 
    id: 1, 
    title: "The Great Gatsby", 
    author: "F. Scott Fitzgerald", 
    price: 15.99,
    authorBio: "F. Scott Fitzgerald was an American novelist, essayist, and short story writer. He is best known for his novels depicting the flamboyance and excess of the Jazz Age.",
    topBooks: ["The Great Gatsby", "Tender Is the Night", "This Side of Paradise"]
  },
  { 
    id: 2, 
    title: "To Kill a Mockingbird", 
    author: "Harper Lee", 
    price: 12.49,
    authorBio: "Harper Lee was an American novelist widely known for 'To Kill a Mockingbird', which won the 1961 Pulitzer Prize and became a classic of modern American literature.",
    topBooks: ["To Kill a Mockingbird", "Go Set a Watchman"]
  },
  { 
    id: 3, 
    title: "1984", 
    author: "George Orwell", 
    price: 14.00,
    authorBio: "George Orwell was an English novelist, essayist, journalist, and critic. His work is characterized by lucid prose, biting social criticism, and opposition to totalitarianism.",
    topBooks: ["1984", "Animal Farm", "Homage to Catalonia"]
  },
  { 
    id: 4, 
    title: "Pride and Prejudice", 
    author: "Jane Austen", 
    price: 9.99,
    authorBio: "Jane Austen was an English novelist known primarily for her six major novels, which interpret, critique and comment upon the British landed gentry at the end of the 18th century.",
    topBooks: ["Pride and Prejudice", "Sense and Sensibility", "Emma"]
  }
];