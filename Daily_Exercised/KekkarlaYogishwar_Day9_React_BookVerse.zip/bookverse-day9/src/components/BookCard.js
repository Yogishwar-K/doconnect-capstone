import React from 'react';
import PropTypes from 'prop-types';

const BookCard = ({ book, viewMode, onSelectBook }) => {
  if (viewMode === 'list') {
    return (
      <div className="card mb-3 shadow-sm border-0 bg-white">
        <div className="card-body d-flex flex-column flex-md-row justify-content-between align-items-center">
          <div>
            <h5 className="card-title text-primary fw-bold mb-1">{book.title}</h5>
            <h6 className="card-subtitle text-muted mb-2">by {book.author}</h6>
          </div>
          <div className="d-flex align-items-center gap-3 mt-3 mt-md-0">
            <span className="badge bg-success fs-6 px-3 py-2">${book.price.toFixed(2)}</span>
            <button className="btn btn-outline-primary btn-sm" onClick={() => onSelectBook(book)}>
              View Author
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card h-100 shadow-sm border-0 bg-white">
      <div className="card-body d-flex flex-column">
        <h5 className="card-title text-primary fw-bold">{book.title}</h5>
        <h6 className="card-subtitle text-muted mb-3">by {book.author}</h6>
        <div className="mt-auto d-flex justify-content-between align-items-center border-top pt-3">
          <span className="fs-5 fw-bold text-success">${book.price.toFixed(2)}</span>
          <button className="btn btn-outline-primary btn-sm" onClick={() => onSelectBook(book)}>
            Author Info
          </button>
        </div>
      </div>
    </div>
  );
};

BookCard.propTypes = {
  book: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
  }).isRequired,
  viewMode: PropTypes.string.isRequired,
  onSelectBook: PropTypes.func.isRequired,
};

export default BookCard;