import React from 'react';
import BookCard from './BookCard';

const BookList = ({ books, viewMode, onSelectBook }) => {
  if (books.length === 0) {
    return (
      <div className="alert alert-warning text-center mt-4 shadow-sm" role="alert">
        No books found matching your search.
      </div>
    );
  }

  if (viewMode === 'grid') {
    return (
      <div className="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4">
        {books.map((book) => (
          <div className="col" key={book.id}>
            <BookCard book={book} viewMode={viewMode} onSelectBook={onSelectBook} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="d-flex flex-column gap-1">
      {books.map((book) => (
        <BookCard key={book.id} book={book} viewMode={viewMode} onSelectBook={onSelectBook} />
      ))}
    </div>
  );
};

export default BookList;