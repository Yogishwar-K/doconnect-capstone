import React, { Component } from 'react';

class AuthorInfo extends Component {
  componentDidMount() {
    console.log(`[Lifecycle Log] componentDidMount: Loaded data for ${this.props.book.author}`);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.book.id !== this.props.book.id) {
      console.log(`[Lifecycle Log] componentDidUpdate: Author changed to ${this.props.book.author}`);
    }
  }

  componentWillUnmount() {
    console.log(`[Lifecycle Log] componentWillUnmount: AuthorInfo component destroyed.`);
  }

  render() {
    const { book, onClose } = this.props;

    return (
      <div className="card border-0 shadow-lg mt-4 mt-lg-0 sticky-top" style={{ top: '20px' }}>
        <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
          <h5 className="mb-0 fw-bold">About {book.author}</h5>
          <button type="button" className="btn-close btn-close-white" onClick={onClose} aria-label="Close"></button>
        </div>
        <div className="card-body p-4">
          <h6 className="text-uppercase fw-bold text-secondary border-bottom pb-2 mb-3">Biography</h6>
          <p className="card-text text-dark" style={{ lineHeight: '1.6' }}>{book.authorBio}</p>
          
          <h6 className="text-uppercase fw-bold text-secondary border-bottom pb-2 mt-4 mb-3">Top Books</h6>
          <ul className="list-group list-group-flush">
            {book.topBooks.map((topBook, index) => (
              <li key={index} className="list-group-item px-0 text-dark fw-medium">
                <span className="text-primary me-2">•</span> {topBook}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }
}

export default AuthorInfo;