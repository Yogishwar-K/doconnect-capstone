import React, { useState, useRef } from 'react';
import BookList from './components/BookList';
import AuthorInfo from './components/AuthorInfo';
import { featuredBooks } from './data/books';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

export default function App() {
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBook, setSelectedBook] = useState(null);

  const searchInputRef = useRef(null);

  const handleFocusClick = () => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  const handleSearchClick = () => {
    if (searchInputRef.current) {
      setSearchTerm(searchInputRef.current.value);
    }
  };

  const filteredBooks = featuredBooks.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container-fluid py-5" style={{ minHeight: '100vh', backgroundColor: '#f4f6f9' }}>
      <div className="container">
        
        <header className="mb-5 text-center text-md-start">
          <h1 className="display-4 fw-bolder text-primary mb-2">📚 BookVerse</h1>
          <p className="lead text-secondary">Discover featured books and learn about their authors.</p>
        </header>

        <div className="card shadow-sm border-0 mb-4 bg-white">
          <div className="card-body d-flex flex-column flex-lg-row justify-content-between align-items-center gap-4">
            
            <div className="input-group" style={{ maxWidth: '600px' }}>
              <input
                type="text"
                className="form-control bg-light"
                placeholder="Search by book title..."
                ref={searchInputRef}
                defaultValue=""
              />
              <button className="btn btn-outline-secondary px-4" onClick={handleFocusClick}>
                Focus Input
              </button>
              <button className="btn btn-primary px-4 fw-bold" onClick={handleSearchClick}>
                Search
              </button>
            </div>

            <div className="btn-group shadow-sm">
              <button 
                className={`btn px-4 ${viewMode === 'grid' ? 'btn-primary' : 'btn-outline-primary bg-white'}`}
                onClick={() => setViewMode('grid')}
              >
                Grid View
              </button>
              <button 
                className={`btn px-4 ${viewMode === 'list' ? 'btn-primary' : 'btn-outline-primary bg-white'}`}
                onClick={() => setViewMode('list')}
              >
                List View
              </button>
            </div>
          </div>
        </div>

        <div className="row">
          <div className={selectedBook ? "col-lg-8" : "col-12"}>
            <BookList 
              books={filteredBooks} 
              viewMode={viewMode} 
              onSelectBook={(book) => setSelectedBook(book)} 
            />
          </div>

          {selectedBook && (
            <div className="col-lg-4">
              <AuthorInfo 
                book={selectedBook} 
                onClose={() => setSelectedBook(null)} 
              />
            </div>
          )}
        </div>

      </div>
    </div>
  );
}