// BookVerse Advanced Queries
// Author: Kekkarla Yogishwar

use BookVerseDB;

// index testing
// check stats without index
db.books.find({ genre: "Science Fiction" }).explain("executionStats");

// add index on genre
db.books.createIndex({ genre: 1 });

// check stats after index
db.books.find({ genre: "Science Fiction" }).explain("executionStats");

// drop index
db.books.dropIndex({ genre: 1 });


// aggregations

// avg rating per book
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$_id", title: { $first: "$title" }, avgRating: { $avg: "$ratings.score" } } }
]);

// top 3 highest-rated books
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$_id", title: { $first: "$title" }, avgRating: { $avg: "$ratings.score" } } }
]);

// 2. Retrieve the top 3 highest-rated books
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$_id", title: { $first: "$title" }, avgRating: { $avg: "$ratings.score" } } },
  { $sort: { avgRating: -1 } },
  { $limit: 3 }
]);

// books per genre
db.books.aggregate([
  { $group: { _id: "$genre", bookCount: { $sum: 1 } } }
]);

// authors with > 2 books
db.books.aggregate([
  { $group: { _id: "$genre", bookCount: { $sum: 1 } } }
]);

// 4. Find authors who have more than 2 books published
db.books.aggregate([
  { $group: { _id: "$authorId", bookCount: { $sum: 1 } } },
  { $match: { bookCount: { $gt: 2 } } }
]);

// total rating points per author
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$authorId", totalRewardPoints: { $sum: "$ratings.score" } } }
]);


// bonus challenge

// test compound index
db.books.createIndex({ genre: 1, publicationYear: 1 });
db.books.find({ genre: "Fantasy", publicationYear: { $gt: 1950 } }).explain("executionStats");

// top-rated author by avg book score
db.books.aggregate([
  { $unwind: "$ratings" },
  { $group: { _id: "$authorId", avgAuthorScore: { $avg: "$ratings.score" } } },
  { $sort: { avgAuthorScore: -1 } },
  { $limit: 1 }
]);