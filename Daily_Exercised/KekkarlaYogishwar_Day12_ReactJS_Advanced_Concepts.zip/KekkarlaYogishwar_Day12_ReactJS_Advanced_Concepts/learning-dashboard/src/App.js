import React, { useState, Suspense, lazy } from 'react';
import StatsCard from './components/StatsCard';
import ErrorBoundary from './components/ErrorBoundary';
import Modal from './components/Modal';
import BuggyComponent from './components/BuggyComponent';

// Dynamically import heavy components only when requested
const CourseDetails = lazy(() => import('./components/CourseDetails'));
const InstructorProfile = lazy(() => import('./components/InstructorProfile'));

export default function App() {
  // UI visibility state for Lazy Loading
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);

  // Modal Portal state
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Error Boundary trigger state
  const [crashComponent, setCrashComponent] = useState(false);

  // State for system metrics, structured to allow selective updates
  const [stats, setStats] = useState({
    activeStudents: { value: 1240, lastUpdated: new Date().toLocaleTimeString() },
    courseModules: { value: 42, lastUpdated: new Date().toLocaleTimeString() },
    serverUptime: { value: 99.9, lastUpdated: new Date().toLocaleTimeString() }
  });

  // Handler to selectively update a single metric to verify memoization
  const simulateTrafficUpdate = () => {
    setStats(prev => ({
      ...prev,
      activeStudents: {
        value: prev.activeStudents.value + Math.floor(Math.random() * 10),
        lastUpdated: new Date().toLocaleTimeString()
      }
    }));
  };

  return (
    <div className="container py-5">
      <header className="d-flex justify-content-between align-items-center mb-5 border-bottom pb-3">
        <h1 className="text-dark fw-bold h2 mb-0">Learning Management Dashboard</h1>
        <button className="btn btn-outline-primary" onClick={() => setIsModalOpen(true)}>
          🔔 Notifications
        </button>
      </header>

      {/* Pure Components Section */}
      <section className="mb-5 p-4 bg-light rounded shadow-sm">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h3 className="h5 mb-0 text-secondary">System Metrics</h3>
          <button className="btn btn-warning btn-sm fw-bold" onClick={simulateTrafficUpdate}>
            Simulate Traffic Spike
          </button>
        </div>
        
        <div className="row row-cols-1 row-cols-md-3 g-4">
          <StatsCard title="Active Students" value={stats.activeStudents.value} lastUpdated={stats.activeStudents.lastUpdated} />
          <StatsCard title="Course Modules" value={stats.courseModules.value} lastUpdated={stats.courseModules.lastUpdated} />
          <StatsCard title="Server Uptime (%)" value={stats.serverUptime.value} lastUpdated={stats.serverUptime.lastUpdated} />
        </div>
      </section>

      {/* Error Boundary Section */}
      <section className="mb-5 p-4 border rounded border-danger bg-white">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h3 className="h5 mb-0 text-secondary">System Health Monitor</h3>
          <button className="btn btn-danger btn-sm fw-bold" onClick={() => setCrashComponent(true)}>
            Force Component Crash
          </button>
        </div>
        {/* Wrapping the vulnerable component in the boundary */}
        <ErrorBoundary>
          <BuggyComponent triggerError={crashComponent} />
        </ErrorBoundary>
      </section>

      {/* Lazy Loading Section */}
      <section className="mb-5">
        <h3 className="h5 mb-3 text-secondary">Platform Modules</h3>
        <div className="d-flex gap-3 mb-4">
          <button className="btn btn-primary" onClick={() => setShowCourse(!showCourse)}>
            {showCourse ? 'Hide' : 'View'} Course Details
          </button>
          <button className="btn btn-success" onClick={() => setShowInstructor(!showInstructor)}>
            {showInstructor ? 'Hide' : 'View'} Instructor Profile
          </button>
        </div>

        {/* Suspense boundary */}
        <Suspense fallback={
          <div className="d-flex align-items-center text-primary p-3">
            <div className="spinner-border spinner-border-sm me-3" role="status"></div>
            <strong>Fetching module payload...</strong>
          </div>
        }>
          {showCourse && <CourseDetails />}
          {showInstructor && <InstructorProfile />}
        </Suspense>
      </section>

      {/* React Portal Mount */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <div className="text-center">
          <h4 className="fw-bold mb-3 text-primary">System Alert</h4>
          <p className="text-muted">You have no new messages at this time. All microservices are operating optimally.</p>
          <button className="btn btn-primary w-100 mt-3" onClick={() => setIsModalOpen(false)}>
            Acknowledge
          </button>
        </div>
      </Modal>
    </div>
  );
}