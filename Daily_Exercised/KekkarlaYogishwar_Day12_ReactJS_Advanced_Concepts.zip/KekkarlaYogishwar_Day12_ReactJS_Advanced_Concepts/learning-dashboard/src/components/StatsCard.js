import React from 'react';

// Memoized component to optimize rendering performance
const StatsCard = React.memo(({ title, value, lastUpdated }) => {
  // Console logging to demonstrate when the component re-renders
  console.log(`[Render Triggered] StatsCard: ${title}`);

  return (
    <div className="col">
      <div className="card h-100 shadow-sm text-center">
        <div className="card-body">
          <h6 className="text-muted text-uppercase mb-2">{title}</h6>
          <h2 className="display-5 fw-bold mb-0">{value}</h2>
        </div>
        <div className="card-footer bg-transparent text-muted small">
          Last updated: {lastUpdated}
        </div>
      </div>
    </div>
  );
});

export default StatsCard;