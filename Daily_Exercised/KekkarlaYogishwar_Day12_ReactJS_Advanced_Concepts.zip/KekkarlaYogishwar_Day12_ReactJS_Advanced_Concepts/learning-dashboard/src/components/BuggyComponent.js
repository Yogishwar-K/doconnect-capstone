import React from 'react';

// A mock component to throw an error for testing the boundary
export default function BuggyComponent({ triggerError }) {
  if (triggerError) {
    throw new Error("Simulated component failure during render!");
  }
  
  return (
    <div className="card shadow-sm border-info text-center p-3 mb-3">
      <h6 className="text-info mb-0">System Status: Stable</h6>
    </div>
  );
}