import React, { Component } from 'react';

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorInfo: null };
  }

  // Update state so the next render will show the fallback UI
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  // Log error details to console for debugging purposes
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught an error:", error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="alert alert-danger shadow-sm" role="alert">
          <h5 className="alert-heading fw-bold">Oops! Component Failed to Load</h5>
          <p className="mb-0">We encountered an issue rendering this widget. The engineering team has been notified.</p>
        </div>
      );
    }
    return this.props.children;
  }
}