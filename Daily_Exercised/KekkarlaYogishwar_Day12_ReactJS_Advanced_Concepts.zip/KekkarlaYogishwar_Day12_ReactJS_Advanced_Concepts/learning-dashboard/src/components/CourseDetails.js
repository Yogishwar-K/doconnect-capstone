import React from 'react';

export default function CourseDetails() {
  return (
    <div className="card shadow-sm mb-3 border-primary">
      <div className="card-body">
        <h4 className="text-primary">Advanced Quantum Cryptography</h4>
        <p className="text-muted">Explore the principles of quantum mechanics applied to secure communication.</p>
        <ul className="list-group list-group-flush">
          <li className="list-group-item">Module 1: Qubit States and Superposition</li>
          <li className="list-group-item">Module 2: Quantum Key Distribution (QKD)</li>
          <li className="list-group-item">Module 3: Shor's Algorithm Impacts</li>
        </ul>
      </div>
    </div>
  );
}