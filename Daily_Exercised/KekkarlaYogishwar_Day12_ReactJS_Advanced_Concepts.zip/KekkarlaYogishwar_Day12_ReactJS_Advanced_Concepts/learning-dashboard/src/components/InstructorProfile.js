import React from 'react';

export default function InstructorProfile() {
  return (
    <div className="card shadow-sm mb-3 border-success">
      <div className="card-body">
        <h4 className="text-success">Instructor: Dr. Alan Turing</h4>
        <p className="text-muted">Lead Security Researcher with 15+ years of experience in cryptographic protocol design.</p>
        <button className="btn btn-outline-success btn-sm">Contact Instructor</button>
      </div>
    </div>
  );
}