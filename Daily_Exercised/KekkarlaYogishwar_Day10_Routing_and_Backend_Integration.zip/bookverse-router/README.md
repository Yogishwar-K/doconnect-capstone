# BookVerse - Routing & Backend Integration

**Grader Note regarding the HOC Loading Spinner:**
Due to the speed of the local `json-server`, the data fetch resolves almost instantaneously (under 5ms), making the loading spinner invisible to the human eye. 

To verify the Higher Order Component (HOC) loading spinner:
1. Open the app in your browser.
2. Open Developer Tools (F12).
3. Go to the **Network** tab.
4. Set throttling to **"Slow 3G"** or **"Fast 3G"**.
5. Navigate between pages to see the loading state.