import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import Home from './pages/Home';
import BookDetails from './pages/BookDetails';
import UserGreeting from './components/UserGreeting';

// Wrapper component to apply CSS transitions based on route changes
const TransitionWrapper = ({ children }) => {
  const location = useLocation();
  return <div key={location.pathname} className="page-transition">{children}</div>;
};

export default function App() {
  return (
    <BrowserRouter>
      <div className="container py-5">
        <header className="mb-5 text-center">
          <h1 className="display-4 fw-bolder text-primary">📚 BookVerse</h1>
          <UserGreeting render={(greeting, name) => (
            <p className="lead text-secondary">{greeting}, {name}! Explore our collection.</p>
          )} />
        </header>

        <TransitionWrapper>
          <Routes>
            <Route path="/home" element={<Home />} />
            <Route path="/book/:id" element={<BookDetails />} />
            {/* Redirect any unknown route to home */}
            <Route path="*" element={<Navigate to="/home" />} />
          </Routes>
        </TransitionWrapper>
      </div>
    </BrowserRouter>
  );
}