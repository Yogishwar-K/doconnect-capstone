import React from 'react';

const UserGreeting = ({ render }) => {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good Morning" : hour < 18 ? "Good Afternoon" : "Good Evening";
  return render(greeting, "Reader");
};

export default UserGreeting;