import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import withLoading from '../components/withLoading';

const DetailsView = ({ book }) => {
  if (!book) return null;
  return (
    <div className="card shadow border-0">
      <div className="card-body p-5">
        <h2 className="text-primary fw-bold mb-1">{book.title}</h2>
        <h5 className="text-muted mb-4">Authored by {book.author}</h5>
        <h3 className="text-success mb-4">${book.price.toFixed(2)}</h3>
        <p className="lead">{book.desc}</p>
        <Link to="/home" className="btn btn-secondary mt-4">&larr; Back to Home</Link>
      </div>
    </div>
  );
};

const DetailsWithLoading = withLoading(DetailsView);

export default function BookDetails() {
  const { id } = useParams(); // Using React Router's useParams hook!
  const [book, setBook] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    axios.get(`http://localhost:5000/books/${id}`)
      .then(res => {
        setBook(res.data);
        setIsLoading(false);
      });
  }, [id]);

  return <DetailsWithLoading isLoading={isLoading} book={book} />;
}