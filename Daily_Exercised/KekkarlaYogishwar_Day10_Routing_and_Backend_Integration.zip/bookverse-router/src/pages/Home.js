import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import withLoading from '../components/withLoading';

const BookList = ({ books }) => (
  <div className="row row-cols-1 row-cols-md-3 g-4">
    {books.map(book => (
      <div className="col" key={book.id}>
        <div className="card h-100 shadow-sm border-0">
          <div className="card-body">
            <h5 className="card-title text-primary fw-bold">{book.title}</h5>
            <h6 className="card-subtitle text-muted mb-3">by {book.author}</h6>
            <Link to={`/book/${book.id}`} className="btn btn-outline-primary w-100">View Details</Link>
          </div>
        </div>
      </div>
    ))}
  </div>
);

const BookListWithLoading = withLoading(BookList);

export default function Home() {
  const [books, setBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetching data from our json-server
    axios.get('http://localhost:5000/books')
      .then(res => {
        setBooks(res.data);
        setIsLoading(false);
      });
  }, []);

  return <BookListWithLoading isLoading={isLoading} books={books} />;
}