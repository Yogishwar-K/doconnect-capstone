import React, { useState } from 'react';
import BookList from './components/BookList';
import { featuredBooks } from './data/books';
import './App.css';

export default function App() {
  // State 1: Manage Layout Toggle
  const [viewMode, setViewMode] = useState('grid');
  
  // State 2: Controlled Component for Search Input
  const [searchTerm, setSearchTerm] = useState('');

  // Filter books dynamically based on state
  const filteredBooks = featuredBooks.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>📚 BookVerse</h1>
        <p>Discover our featured books collection.</p>
      </header>

      <div className="controls-section">
        {/* Controlled Input Component */}
        <input
          type="text"
          className="search-input"
          placeholder="Search by book title..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        {/* Layout Toggle Buttons */}
        <div className="toggle-buttons">
          <button 
            className={viewMode === 'grid' ? 'active' : ''} 
            onClick={() => setViewMode('grid')}
          >
            Grid View
          </button>
          <button 
            className={viewMode === 'list' ? 'active' : ''} 
            onClick={() => setViewMode('list')}
          >
            List View
          </button>
        </div>
      </div>

      {/* Render the BookList Component and pass props */}
      <main>
        <BookList books={filteredBooks} viewMode={viewMode} />
      </main>
    </div>
  );
}