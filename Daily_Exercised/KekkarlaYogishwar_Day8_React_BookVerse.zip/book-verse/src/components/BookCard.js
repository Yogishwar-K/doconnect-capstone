import React from 'react';

// Functional component receiving props
const BookCard = ({ book, viewMode }) => {
  // Conditional rendering based on the viewMode prop
  if (viewMode === 'list') {
    return (
      <div className="book-card list-layout">
        <div className="book-info">
          <h3>{book.title}</h3>
          <p>by {book.author}</p>
        </div>
        <div className="book-price">
          <span>${book.price.toFixed(2)}</span>
        </div>
      </div>
    );
  }

  // Default Grid Layout
  return (
    <div className="book-card grid-layout">
      <h3>{book.title}</h3>
      <p className="author">by {book.author}</p>
      <div className="price-tag">
        <span>${book.price.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default BookCard;