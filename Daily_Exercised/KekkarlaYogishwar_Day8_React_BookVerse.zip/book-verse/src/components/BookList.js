import React from 'react';
import BookCard from './BookCard';

// Parent component that maps over data to render children
const BookList = ({ books, viewMode }) => {
  if (books.length === 0) {
    return <div className="no-results">No books found matching your search.</div>;
  }

  // Assign CSS class based on the selected view mode
  const containerClass = viewMode === 'grid' ? 'book-container-grid' : 'book-container-list';

  return (
    <div className={containerClass}>
      {books.map((book) => (
        <BookCard key={book.id} book={book} viewMode={viewMode} />
      ))}
    </div>
  );
};

export default BookList;