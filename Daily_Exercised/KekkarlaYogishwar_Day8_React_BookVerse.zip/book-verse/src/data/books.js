export const featuredBooks = [
  { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", price: 15.99 },
  { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", price: 12.49 },
  { id: 3, title: "1984", author: "George Orwell", price: 14.00 },
  { id: 4, title: "Pride and Prejudice", author: "Jane Austen", price: 9.99 },
  { id: 5, title: "The Catcher in the Rye", author: "J.D. Salinger", price: 11.50 },
  { id: 6, title: "The Hobbit", author: "J.R.R. Tolkien", price: 18.25 }
];