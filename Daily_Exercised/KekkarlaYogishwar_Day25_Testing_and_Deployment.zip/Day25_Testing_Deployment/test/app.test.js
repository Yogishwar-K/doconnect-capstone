const chai = require('chai');
const expect = chai.expect;
const request = require('supertest');
const app = require('../server');

describe('API Routing Tests', () => {

    // unit test for courses
    it('should GET all courses', async () => {
        const res = await request(app).get('/api/courses');
        
        expect(res.status).to.equal(200);
        expect(res.body).to.be.an('array');
        expect(res.body.length).to.be.greaterThan(0);
    });

    // integration test for users
    it('should POST a new user', async () => {
        const res = await request(app)
            .post('/api/users')
            .send({ name: 'Jane Doe' });
            
        expect(res.status).to.equal(201);
        expect(res.body).to.have.property('name', 'Jane Doe');
    });

    it('should GET all users including the new one', async () => {
        const res = await request(app).get('/api/users');
        
        expect(res.status).to.equal(200);
        expect(res.body.length).to.equal(2);
    });

});