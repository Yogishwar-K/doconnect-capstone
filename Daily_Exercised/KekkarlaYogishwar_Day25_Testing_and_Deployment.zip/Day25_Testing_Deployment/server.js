const express = require('express');
const app = express();

// use port from environment variables for deployment
const PORT = process.env.PORT || 3000;

app.use(express.json());

// dummy database
let courses = [{ id: 1, name: "Node.js Basics" }];
let users = [{ id: 1, name: "John Doe" }];

// status route for deployment health check
app.get('/status', (req, res) => {
    res.send("App is live");
});

// course routes
app.get('/api/courses', (req, res) => {
    res.json(courses);
});

// user routes
app.get('/api/users', (req, res) => {
    res.json(users);
});

app.post('/api/users', (req, res) => {
    const newUser = { 
        id: users.length + 1, 
        name: req.body.name 
    };
    users.push(newUser);
    res.status(201).json(newUser);
});

// start server only if ran directly (not during testing)
if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`server running on port ${PORT}`);
    });
}

// export for testing
module.exports = app;