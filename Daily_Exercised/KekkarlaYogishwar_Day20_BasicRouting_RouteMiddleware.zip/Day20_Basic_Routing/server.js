const express = require('express');
const app = express();

const PORT = 4000;

// basic route setup
app.get('/', (req, res) => {
    res.send("Welcome to SkillSphere LMS API");
});

// route middleware for validation
const validateCourseId = (req, res, next) => {
    const courseId = req.params.id;
    
    // check if the id is strictly a number
    if (isNaN(courseId)) {
        return res.status(400).json({ error: "Invalid course ID" });
    }
    
    // if it is a number, proceed to the actual route
    next();
};

// dynamic routing with middleware applied
app.get('/courses/:id', validateCourseId, (req, res) => {
    const courseId = req.params.id;
    
    res.json({
        id: courseId,
        name: "React Mastery",
        duration: "6 weeks"
    });
});

app.listen(PORT, () => {
    console.log(`server running on http://localhost:${PORT}`);
});