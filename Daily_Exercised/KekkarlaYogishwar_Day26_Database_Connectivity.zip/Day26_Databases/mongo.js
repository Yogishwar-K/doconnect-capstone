require('dotenv').config();
const mongoose = require('mongoose');

// define schemas
const userSchema = new mongoose.Schema({ name: String, email: String });
const enrollmentSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    courseName: String,
    status: String
});

// define models
const User = mongoose.model('User', userSchema);
const Enrollment = mongoose.model('Enrollment', enrollmentSchema);

async function run() {
    // connect to mongodb
    await mongoose.connect(process.env.MONGO_URI);
    console.log('connected to mongodb');

    // clear old data for clean test
    await User.deleteMany({});
    await Enrollment.deleteMany({});

    // create dummy user and enrollment
    const student = await User.create({ name: 'Alice', email: 'alice@example.com' });
    await Enrollment.create({ user: student._id, courseName: 'Node.js Basics', status: 'Active' });

    // fetch and populate enrollment data    
    const enrollments = await Enrollment.find().populate('user').lean();  // .lean() strips out the heavy mongoose connection data so it logs cleanly!
    
    console.log('successfully fetched enrollment details:');
    console.dir(enrollments, { depth: null });
    
    process.exit(0);
}

run().catch(console.error);