require('dotenv').config();
const mysql = require('mysql2/promise');

async function run() {
    // connect to mysql (without specifying db yet)
    const connection = await mysql.createConnection({
        host: process.env.MYSQL_HOST,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASS
    });

    // create database and table automatically
    await connection.query('CREATE DATABASE IF NOT EXISTS skillsphere');
    await connection.query('USE skillsphere');
    await connection.query(`
        CREATE TABLE IF NOT EXISTS courses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            duration VARCHAR(50)
        )
    `);

    // insert new course data
    const [result] = await connection.execute(
        'INSERT INTO courses (title, duration) VALUES (?, ?)',
        ['Introduction to SQL', '4 weeks']
    );

    console.log(`INSERT INTO courses successful. inserted id: ${result.insertId}`);
    process.exit(0);
}

run().catch(console.error);