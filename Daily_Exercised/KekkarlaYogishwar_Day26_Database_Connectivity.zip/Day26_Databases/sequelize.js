require('dotenv').config();
const { Sequelize, DataTypes } = require('sequelize');

// initialize sequelize
const sequelize = new Sequelize('skillsphere', process.env.MYSQL_USER, process.env.MYSQL_PASS, {
    host: process.env.MYSQL_HOST,
    dialect: 'mysql',
    logging: false
});

// define models
const Instructor = sequelize.define('Instructor', {
    name: { type: DataTypes.STRING, allowNull: false }
});

const Course = sequelize.define('Course', {
    title: { type: DataTypes.STRING, allowNull: false }
});

// implement one-to-many relationship
Instructor.hasMany(Course);
Course.belongsTo(Instructor);

async function run() {
    // sync database and recreate tables
    await sequelize.sync({ force: true });
    console.log('database synced');

    // create dummy instructor and courses
    const instructor = await Instructor.create({ name: 'Dr. Smith' });
    await Course.bulkCreate([
        { title: 'Advanced Express', InstructorId: instructor.id },
        { title: 'Database Design', InstructorId: instructor.id }
    ]);

    // query retrieves all courses by an instructor
    const results = await Instructor.findAll({
        include: Course
    });

    console.log('instructor and their courses:');
    console.dir(results.map(i => i.toJSON()), { depth: null });
    
    process.exit(0);
}

run().catch(console.error);