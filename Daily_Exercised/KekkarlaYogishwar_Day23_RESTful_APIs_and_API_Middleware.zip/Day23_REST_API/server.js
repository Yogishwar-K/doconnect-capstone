const express = require('express');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = 3000;

// parse incoming json data
app.use(express.json());

// restrict users to 5 requests per minute
const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    message: { error: "Too many requests" }
});
app.use('/api/', apiLimiter);

// in-memory database
let courses = [
    { id: 1, name: "Node.js Basics", duration: "4 weeks" }
];

// get all courses
app.get('/api/courses', (req, res) => {
    res.json(courses);
});

// add a new course with validation
app.post('/api/courses', 
    [
        body('name').notEmpty().withMessage('Course name is required'),
        body('duration').notEmpty().withMessage('Course duration is required')
    ],
    (req, res) => {
        // return exact error message if validation fails
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const newCourse = {
            id: courses.length > 0 ? courses[courses.length - 1].id + 1 : 1,
            name: req.body.name,
            duration: req.body.duration
        };

        courses.push(newCourse);
        res.status(201).json(newCourse);
    }
);

// update an existing course
app.put('/api/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const course = courses.find(c => c.id === courseId);

    if (!course) {
        return res.status(404).json({ error: "course not found" });
    }

    course.name = req.body.name || course.name;
    course.duration = req.body.duration || course.duration;

    res.json(course);
});

// delete a course
app.delete('/api/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const initialLength = courses.length;

    courses = courses.filter(c => c.id !== courseId);

    if (courses.length === initialLength) {
        return res.status(404).json({ error: "course not found" });
    }

    res.json({ message: "course deleted successfully" });
});

app.listen(PORT, () => {
    console.log(`server running on http://localhost:${PORT}`);
});