const http = require('http');
const fs = require('fs').promises;
const path = require('path');

// Create the HTTP server
const server = http.createServer(async (req, res) => {
    try {
        // Routing logic based on the requested URL
        if (req.url === '/' || req.url === '/home') {
            // Read and serve the index.html file
            const data = await fs.readFile(path.join(__dirname, 'index.html'), 'utf8');
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        } else if (req.url === '/about') {
            // Read and serve the about.html file
            const data = await fs.readFile(path.join(__dirname, 'about.html'), 'utf8');
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        } else {
            // Handle 404 Not Found
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 - Page Not Found</h1>');
        }
    } catch (error) {
        // Handle server errors
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 - Internal Server Error');
        console.error("Server error:", error);
    }
});

// Start listening on port 3000
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is running!`);
    console.log(`Visit: http://localhost:${PORT}`);
    console.log(`Press Ctrl + C to stop the server.`);
});