const EventEmitter = require('events');

// Initialize the Event Emitter
const authEmitter = new EventEmitter();

// Register Event Listeners (What happens when an event is triggered)
authEmitter.on('userLoggedIn', (user) => {
    console.log(`User ${user} logged in.`);
});

authEmitter.on('userLoggedOut', (user) => {
    console.log(`User ${user} logged out.`);
});

// Bonus: Listener for session expiration
authEmitter.on('sessionExpired', (user) => {
    console.log(`User ${user}'s session has expired due to inactivity.`);
});

// Trigger (Emit) the events dynamically
const currentUser = 'John';

// Simulate immediate login and logout
authEmitter.emit('userLoggedIn', currentUser);
authEmitter.emit('userLoggedOut', currentUser);

// Bonus: Simulate session expiration after 5 seconds (5000 milliseconds)
console.log("Waiting 5 seconds for session to expire...");
setTimeout(() => {
    authEmitter.emit('sessionExpired', currentUser);
}, 5000);