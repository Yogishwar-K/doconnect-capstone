const fs = require('fs').promises;

// Grab the user's input from the terminal arguments.
// If they don't provide one, default to the string requested in the assignment.
const userInput = process.argv.slice(2).join(' ') || "Node.js is awesome!";
const filePath = 'feedback.txt';

async function processFile() {
    try {
        // Write the input to the file
        await fs.writeFile(filePath, userInput);
        console.log("Data written successfully.");

        // Read the file back
        console.log("Reading file...");
        const data = await fs.readFile(filePath, 'utf8');
        
        // Print the contents to the console
        console.log(data);
    } catch (error) {
        console.error("An error occurred:", error);
    }
}

// Execute the async function
processFile();