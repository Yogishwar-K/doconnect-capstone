require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcryptjs');
const User = require('./models/User');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// configure session
app.use(session({
    secret: 'super-secret-key',
    resave: false,
    saveUninitialized: false
}));

// initialize passport
app.use(passport.initialize());
app.use(passport.session());

// connect to mongodb
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('connected to mongodb'))
    .catch(err => console.error('database connection error:', err));

// passport local strategy
passport.use(new LocalStrategy({ usernameField: 'name' }, async (name, password, done) => {
    try {
        const user = await User.findOne({ name });
        if (!user) return done(null, false, { message: 'user not found' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return done(null, false, { message: 'incorrect password' });

        return done(null, user);
    } catch (err) {
        return done(err);
    }
}));

// serialize and deserialize user for sessions
passport.serializeUser((user, done) => done(null, user.id));

passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        done(null, user);
    } catch (err) {
        done(err);
    }
});

// route to render forms
app.get('/register', (req, res) => res.render('register'));
app.get('/login', (req, res) => res.render('login'));

// handle registration with password hashing
app.post('/register', async (req, res) => {
    try {
        const { name, password, role } = req.body;
        
        // hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const newUser = new User({ name, password: hashedPassword, role });
        await newUser.save();
        
        // redirect to login after successful registration
        res.redirect('/login');
    } catch (error) {
        console.error(error);
        res.status(500).send("error registering user");
    }
});

// handle login
app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) return next(err);
        
        // If authentication fails, show the exact error message
        if (!user) {
            return res.send(`<h2>Login Failed</h2><p>Reason: ${info.message}</p><br><a href="/login">Try again</a>`);
        }
        
        // If successful, log the user in and redirect
        req.logIn(user, (err) => {
            if (err) return next(err);
            return res.redirect('/admin');
        });
    })(req, res, next);
});

// role checking middleware
const checkRole = (role) => {
    return (req, res, next) => {
        if (!req.isAuthenticated()) {
            return res.status(401).send('Access Denied: Please log in');
        }
        if (req.user.role !== role) {
            return res.status(403).send('Access Denied');
        }
        next();
    };
};

// protected admin route
app.get('/admin', checkRole('admin'), (req, res) => {
    res.send(`Welcome, Admin! (Logged in as: ${req.user.name})`);
});

app.listen(PORT, () => console.log(`server running on http://localhost:${PORT}`));