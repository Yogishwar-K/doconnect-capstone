const mongoose = require('mongoose');

// define user schema
const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    password: { type: String, required: true },
    role: { type: String, default: 'user' }
});

module.exports = mongoose.model('User', userSchema);