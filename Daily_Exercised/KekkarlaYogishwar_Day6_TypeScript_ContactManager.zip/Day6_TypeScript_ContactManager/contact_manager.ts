/**
 * Instruction 1: Define Interfaces
 * Defines the structure of a Contact object.
 */
interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

/**
 * Instruction 2 & 3: Implement Classes with Error Handling
 * Manages a list of contacts with full CRUD capabilities.
 */
class ContactManager {
    private contacts: Contact[] = [];

    /**
     * Adds a new contact to the list.
     * Story 1 & 6: Success confirmation provided.
     */
    addContact(contact: Contact): void {
        this.contacts.push(contact);
        console.log(`[SUCCESS] Contact "${contact.name}" (ID: ${contact.id}) has been added.`);
    }

    /**
     * Returns the list of all contacts.
     * Story 2: Viewing the list.
     */
    viewContacts(): Contact[] {
        return this.contacts;
    }

    /**
     * Modifies an existing contact by ID.
     * Story 3, 5 & 6: Supports partial updates and error checking.
     */
    modifyContact(id: number, updatedContact: Partial<Contact>): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);

        if (contactIndex === -1) {
            // User Story 5: Error message for non-existent contact
            console.error(`[ERROR] Modification failed: Contact with ID ${id} does not exist.`);
            return;
        }

        // Apply partial updates using the spread operator
        // User Story 6: Confirmation message
        const originalName = this.contacts[contactIndex].name;
        this.contacts[contactIndex] = { ...this.contacts[contactIndex], ...updatedContact };
        console.log(`[SUCCESS] Contact "${originalName}" (ID: ${id}) has been successfully modified.`);
    }

    /**
     * Deletes a contact by ID.
     * Story 4, 5 & 6: Error checking and confirmation.
     */
    deleteContact(id: number): void {
        const contactIndex = this.contacts.findIndex(c => c.id === id);

        if (contactIndex === -1) {
            // User Story 5: Error message for non-existent contact
            console.error(`[ERROR] Deletion failed: Contact with ID ${id} was not found.`);
            return;
        }

        const removedName = this.contacts[contactIndex].name;
        this.contacts.splice(contactIndex, 1);
        
        // User Story 6: Confirmation message
        console.log(`[SUCCESS] Contact "${removedName}" (ID: ${id}) has been deleted.`);
    }
}

/**
 * Instruction 4: Testing Script
 * This script verifies all functionalities of the ContactManager.
 */

const manager = new ContactManager();

console.log("--- TEST 1: Adding Contacts ---");
manager.addContact({ id: 101, name: "Alice Smith", email: "alice@example.com", phone: "555-0101" });
manager.addContact({ id: 102, name: "Bob Johnson", email: "bob@example.com", phone: "555-0102" });

console.log("\n--- TEST 2: Viewing Contacts ---");
console.log("Current Directory:", manager.viewContacts());

console.log("\n--- TEST 3: Modifying Contacts ---");
// Successfully modify Bob's phone number only (Partial update)
manager.modifyContact(102, { phone: "555-9999" });

// Attempt to modify a non-existent ID (Error handling)
manager.modifyContact(999, { name: "Ghost" });

console.log("\n--- TEST 4: Deleting Contacts ---");
// Successfully delete Alice
manager.deleteContact(101);

// Attempt to delete a non-existent ID (Error handling)
manager.deleteContact(101); // Already deleted, should show error

console.log("\n--- TEST 5: Final Verification ---");
const finalContacts = manager.viewContacts();
console.log(`Final count: ${finalContacts.length}`);
console.log("Remaining Contacts:", finalContacts);