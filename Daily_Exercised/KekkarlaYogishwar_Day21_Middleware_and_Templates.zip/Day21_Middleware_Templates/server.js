const express = require('express');
const app = express();
const PORT = 3000;

// set ejs as view engine
app.set('view engine', 'ejs');

// custom logging middleware
app.use((req, res, next) => {
    console.log(`[${req.method}]${req.url} at ${new Date().toISOString()}`);
    next();
});

// built-in middleware for parsing post data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// dummy data for template
const courses = [
    { id: 1, title: "Introduction to Node.js", instructor: "Alice" },
    { id: 2, title: "Express Fundamentals", instructor: "Bob" },
    { id: 3, title: "Dynamic Templates with EJS", instructor: "Charlie" }
];

// render ejs template
app.get('/courses', (req, res) => {
    res.render('courses', { courses });
});

// handle post request and return parsed data
app.post('/users', (req, res) => {
    res.json({
        message: "User created successfully",
        data: req.body
    });
});

app.listen(PORT, () => {
    console.log(`server running on http://localhost:${PORT}`);
});