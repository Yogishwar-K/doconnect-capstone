const express = require('express');
const cors = require('cors');
const bookRouter = require('./routes/books');

const app = express();
const PORT = 4000;

// add cors middleware
app.use(cors());

// parse json
app.use(express.json());

// logger
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${req.method}] ${req.url}`);
    next(); 
});

// basic routes
app.get('/', (req, res) => {
    res.send("Welcome to Express Server");
});

app.get('/status', (req, res) => {
    res.json({ server: "running", uptime: "OK" });
});

app.get('/products', (req, res) => {
    const productName = req.query.name;
    
    if (productName) {
        res.json({ query: productName });
    } else {
        res.send("Please provide a product name");
    }
});

// use modular routes
app.use('/books', bookRouter);

// 404 handler
app.use((req, res) => {
    res.status(404).send("Route not found");
});

// bonus: global error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: "Internal Server Error" });
});

app.listen(PORT, () => {
    console.log(`server running on http://localhost:${PORT}`);
});