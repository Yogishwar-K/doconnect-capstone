const express = require('express');
const { body, validationResult } = require('express-validator');
const router = express.Router();

// in-memory db
let books = [
    { id: 1, title: "1984", author: "Orwell" },
    { id: 2, title: "The Alchemist", author: "Coelho" }
];

// get all books
router.get('/', (req, res) => {
    res.json(books);
});

// get a single book by id
router.get('/:id', (req, res) => {
    const bookId = parseInt(req.params.id);
    const book = books.find(b => b.id === bookId);
    
    if (!book) {
        return res.status(404).json({ error: "book not found" });
    }
    
    res.json(book);
});

// add a new book with express-validator
router.post('/', 
    [
        body('title').notEmpty().withMessage('title is required'),
        body('author').notEmpty().withMessage('author is required')
    ],
    (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        
        const { title, author } = req.body;
        
        const newBook = {
            id: books.length > 0 ? books[books.length - 1].id + 1 : 1,
            title,
            author
        };
        
        books.push(newBook);
        res.status(201).json(newBook);
});

// update a book
router.put('/:id', (req, res) => {
    const bookId = parseInt(req.params.id);
    const { title, author } = req.body;
    
    const bookIndex = books.findIndex(b => b.id === bookId);
    
    if (bookIndex === -1) {
        return res.status(404).json({ error: "book not found" });
    }
    
    books[bookIndex] = { 
        ...books[bookIndex], 
        title: title || books[bookIndex].title, 
        author: author || books[bookIndex].author 
    };
    
    res.json(books[bookIndex]);
});

// delete a book
router.delete('/:id', (req, res) => {
    const bookId = parseInt(req.params.id);
    const initialLength = books.length;
    
    books = books.filter(b => b.id !== bookId);
    
    if (books.length === initialLength) {
        return res.status(404).json({ error: "book not found" });
    }
    
    res.json({ message: "book deleted successfully" });
});

module.exports = router;