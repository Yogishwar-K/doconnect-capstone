const fs = require('fs').promises;

// read file, write to new file, handle errors using promise chain
fs.readFile('input.txt', 'utf8')
    .then(data => {
        return fs.writeFile('output.txt', data);
    })
    .then(() => {
        console.log("File copied successfully!");
    })
    .catch(err => {
        console.error("error during file operation:", err);
    });