const fs = require('fs').promises;

async function copyFile() {
    try {
        console.log("starting file copy...");

        // read file
        const data = await fs.readFile('input.txt', 'utf8');

        // bonus: simulate slow network operation (1 sec delay)
        console.log("simulating network delay...");
        await new Promise(res => setTimeout(res, 1000));

        // write file
        await fs.writeFile('output.txt', data);

        console.log("File copied successfully!");
    } catch (err) {
        // handle errors
        console.error("error during file operation:", err);
    }
}

// run the function
copyFile();