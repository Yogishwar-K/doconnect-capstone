const fs = require('fs');

console.log("1. Starting read operation...");

// read file async
fs.readFile('data.txt', 'utf8', (err, data) => {
    if (err) {
        console.error("Error reading file:", err);
        return;
    }
    
    console.log("3. File content retrieved:", data);
    
    // add intentional delay
    setTimeout(() => {
        console.log("4. Read operation completed");
    }, 1500);
});

console.log("2. This prints BEFORE the file finishes reading! (Non-blocking)");