import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import OfflineBanner from './components/OfflineBanner';
import WorkoutTracker from './components/WorkoutTracker';
import ProductAdmin from './components/ProductAdmin';

export default function App() {
  return (
    // Provide theme values at the top-level alongside Redux
    <Provider store={store}>
      <ThemeProvider>
        <OfflineBanner />
        <Navbar />
        <div className="container py-5">
          <div className="row g-4">
            <div className="col-lg-6">
              <WorkoutTracker />
            </div>
            <div className="col-lg-6">
              <ProductAdmin />
            </div>
          </div>
        </div>
      </ThemeProvider>
    </Provider>
  );
}