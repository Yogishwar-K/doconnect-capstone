import React, { useState, useEffect } from 'react';

// Displays an "Offline" banner when network connectivity is lost 
export default function OfflineBanner() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOffline = () => setIsOffline(true);
    const handleOnline = () => setIsOffline(false);

    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  if (!isOffline) return null;

  return (
    <div className="bg-danger text-white text-center py-2 fw-bold w-100" style={{ position: 'sticky', top: 0, zIndex: 1050 }}>
      ⚠️ Network connectivity lost. Viewing offline cache.
    </div>
  );
}