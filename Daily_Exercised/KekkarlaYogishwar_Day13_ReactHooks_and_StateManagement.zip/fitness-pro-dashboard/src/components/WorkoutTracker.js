import React, { useState } from 'react';
import { useTimer } from '../hooks/useTimer';

// Manages sets and timers using the abstracted useTimer hook [cite: 77, 82]
export default function WorkoutTracker() {
  const { seconds, startTimer, stopTimer, resetTimer, isActive } = useTimer(60);
  const [setsCompleted, setSetsCompleted] = useState(0);

  const handleSetComplete = () => {
    setSetsCompleted(prev => prev + 1);
    resetTimer(); // Stops timer with cleanup [cite: 80]
  };

  return (
    <div className="card shadow-sm border-0 h-100">
      <div className="card-body text-center p-4">
        <h5 className="fw-bold mb-4 text-uppercase text-muted">Rest Timer</h5>
        <h1 className="display-1 fw-bold text-primary mb-4">
          00:{seconds < 10 ? `0${seconds}` : seconds}
        </h1>
        <div className="d-flex justify-content-center gap-2 mb-4">
          {!isActive ? (
            <button className="btn btn-success px-4 fw-bold" onClick={startTimer}>Start</button>
          ) : (
            <button className="btn btn-warning px-4 fw-bold" onClick={stopTimer}>Pause</button>
          )}
          <button className="btn btn-outline-secondary px-4 fw-bold" onClick={resetTimer}>Reset</button>
        </div>
        <hr />
        <div className="d-flex justify-content-between align-items-center mt-3">
          <h6 className="mb-0 fw-bold">Sets Completed: <span className="badge bg-primary fs-5 ms-2">{setsCompleted}</span></h6>
          <button className="btn btn-primary btn-sm fw-bold" onClick={handleSetComplete}>Log Set</button>
        </div>
      </div>
    </div>
  );
}