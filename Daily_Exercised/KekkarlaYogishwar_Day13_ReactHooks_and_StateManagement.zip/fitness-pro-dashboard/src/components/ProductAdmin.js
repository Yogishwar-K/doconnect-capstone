import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts, updateProductStock } from '../store/productSlice';

// Uses useSelector and dispatches actions to view and update product data globally [cite: 85, 90, 91]
export default function ProductAdmin() {
  const dispatch = useDispatch();
  const { items, status, error } = useSelector((state) => state.products);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchProducts());
    }
  }, [status, dispatch]);

  const handleRestock = (id) => {
    dispatch(updateProductStock({ id, addedQuantity: 10 }));
  };

  return (
    <div className="card shadow-sm border-0 h-100">
      <div className="card-body p-4">
        <h5 className="fw-bold mb-4 text-uppercase text-muted">Inventory Admin</h5>
        
        {status === 'loading' && <div className="spinner-border text-primary" role="status"></div>}
        {status === 'failed' && <div className="text-danger">{error}</div>}
        
        <ul className="list-group list-group-flush mt-3">
          {items.map(product => (
            <li key={product.id} className="list-group-item d-flex justify-content-between align-items-center bg-transparent px-0">
              <div>
                <h6 className="mb-1 fw-bold">{product.name}</h6>
                <small className="text-muted">Stock: {product.stock} units</small>
              </div>
              <button 
                className="btn btn-sm btn-outline-primary fw-bold" 
                onClick={() => handleRestock(product.id)}
              >
                +10 Restock
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}