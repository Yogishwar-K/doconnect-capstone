import React, { useContext } from 'react';
import { ThemeContext } from '../context/ThemeContext';

// Consumes the theme values to apply styles and toggle mode
export default function Navbar() {
  const { isDarkMode, toggleTheme } = useContext(ThemeContext);

  return (
    <nav className={`navbar navbar-expand-lg ${isDarkMode ? 'navbar-dark bg-dark border-bottom border-secondary' : 'navbar-light bg-white border-bottom shadow-sm'}`}>
      <div className="container">
        <span className="navbar-brand fw-bold">FitnessPro</span>
        <button className={`btn ${isDarkMode ? 'btn-outline-light' : 'btn-outline-dark'} btn-sm`} onClick={toggleTheme}>
          {isDarkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
        </button>
      </div>
    </nav>
  );
}