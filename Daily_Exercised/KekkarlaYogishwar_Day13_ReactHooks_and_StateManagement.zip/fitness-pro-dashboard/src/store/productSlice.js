import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async action to fetch initial inventory data
export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  const response = await axios.get('https://jsonplaceholder.typicode.com/posts?_limit=4');
  // Transform mock data into an inventory structure
  return response.data.map((item, index) => ({
    id: item.id,
    name: `Pro Fitness Gear v${index + 1}`,
    stock: Math.floor(Math.random() * 50) + 10
  }));
});

const productSlice = createSlice({
  name: 'products',
  initialState: {
    items: [],
    status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
    error: null
  },
  reducers: {
    updateProductStock: (state, action) => {
      const { id, addedQuantity } = action.payload;
      const product = state.items.find(p => p.id === id);
      if (product) {
        product.stock += addedQuantity;
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  }
});

export const { updateProductStock } = productSlice.actions;
export default productSlice.reducer;