const CACHE_NAME = 'fitness-pro-cache-v3';
const urlsToCache = ['/', '/index.html'];

// Install and pre-cache core files
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', event => {
  // Ignore non-HTTP requests (like browser extensions)
  if (!event.request.url.startsWith('http')) return;

  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      // Return cached version if it exists
      if (cachedResponse) {
        return cachedResponse;
      }

      // Otherwise, fetch from network and cache it dynamically for later
      return fetch(event.request)
        .then(networkResponse => {
          return caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, networkResponse.clone());
            return networkResponse;
          });
        })
        .catch(() => {
          // Return the cached index.html for page navigations
          if (event.request.mode === 'navigate') {
            return caches.match('/index.html');
          }
          return new Response(null, { status: 503, statusText: 'Offline' });
        });
    })
  );
});