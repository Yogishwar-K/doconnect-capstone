// log node version and file info
console.log("Node.js Version:", process.version);
console.log("Current Directory:", __dirname);
console.log("Current File:", __filename);

// print welcome message every 3 seconds
const timer = setInterval(() => {
  console.log("Welcome to Node.js!");
}, 3000);

// bonus: stop the timer after 10 seconds
setTimeout(() => {
  clearInterval(timer);
  console.log("Timer stopped after 10 seconds.");
}, 10000);