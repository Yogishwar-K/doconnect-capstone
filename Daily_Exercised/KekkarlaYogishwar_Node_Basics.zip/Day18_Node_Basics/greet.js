const moment = require('moment');

// Our custom input starts at Index 2.
const name = process.argv[2];

if (!name) {
    console.log("Please provide a name! Example: node greet.js John");
    process.exit(1);
}

// Format the date using moment.js to match the expected outcome: "Fri Nov 7 2025, 10:45 AM"
const currentDateTime = moment().format('ddd MMM D YYYY, h:mm A');

console.log(`Hello, ${name}! Today is ${currentDateTime}`);