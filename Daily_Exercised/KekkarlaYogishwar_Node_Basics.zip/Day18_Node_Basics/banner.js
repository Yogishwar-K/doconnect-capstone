const figlet = require('figlet');
const chalk = require('chalk');

// Generate the stylized ASCII text
figlet('Welcome to Node.js', (err, data) => {
    if (err) {
        console.log('Something went wrong...');
        console.dir(err);
        return;
    }
    
    // Print the generated text using chalk to make it bright cyan
    console.log(chalk.cyanBright(data));
});